#ifndef __MOVE_MAP__
#define __MOVE_MAP__

#include "matriks.h"
#include "mesinkar.h"
#include "mesinkata.h"
#include "bacafile.h"
#include "graf.h"

void MAP (pembacaan Q);

void MOVE (pembacaan *Q);

#endif
